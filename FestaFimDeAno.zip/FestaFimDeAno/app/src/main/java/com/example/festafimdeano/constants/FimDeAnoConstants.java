package com.example.festafimdeano.constants;

public class FimDeAnoConstants {
    public static final String Presence = "presence_key";
    public static final String Confirmed_Will_Go = "yes";
    public static final String Confirmed_Wont_Go= "no";
}
